package com.sjht.cloud.entrance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sjht.cloud.entrance.entity.EntranceAuditLogEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * ***************************************************
 * @ClassName EntranceAuditLogMapper
 * @Description 审核日志mapper
 * @Author maojianyun
 * @Date 2020/3/9 13:24
 * @Version V1.0
 * ****************************************************
 **/
@Component
@Mapper
public interface EntranceAuditLogMapper extends BaseMapper<EntranceAuditLogEntity> {

    /**
     * 修改审核日志状态
     * @param id
     * @param status
     * @return
     */
    int updateAuditLogStatus(@Param("id") long id, @Param("status") int status);

    /**
     * 得到审核的内容
     * @param appliId
     * @param status
     * @return
     */
    String getAuditLogContent(@Param("appliId") long appliId, @Param("status") int status);

    /**
     * 得到审核的状态
     * @param id
     * @return
     */
    String  getAuditStatus(@Param("id")String id);
}
