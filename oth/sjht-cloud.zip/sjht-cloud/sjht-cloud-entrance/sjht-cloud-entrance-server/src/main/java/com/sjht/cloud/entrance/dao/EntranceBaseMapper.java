package com.sjht.cloud.entrance.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sjht.cloud.entrance.api.dto.UpdateEntranceBaseDto;
import com.sjht.cloud.entrance.api.vo.EntranceBaseVo;
import com.sjht.cloud.entrance.entity.EntranceBaseEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * ***************************************************
 * @ClassName EntranceBaseMapper
 * @Description 基本信息
 * @Author maojianyun
 * @Date 2020/3/3 21:55
 * @Version V1.0
 * ****************************************************
 **/
@Mapper
@Component
public interface EntranceBaseMapper extends BaseMapper<EntranceBaseEntity> {

    /**
     * 查询基本信息
     * @param appliId
     * @return
     */
    EntranceBaseVo getEntranceBaseInfo(@Param("appliId") String appliId);

    /**
     * 更新基本信息
     * @param baseDto
     * @return
     */
    int updateEntranceBaseInfo(@Param("ew")UpdateEntranceBaseDto baseDto);

    /**
     * 修改审核状态
     * @param id
     * @param status
     * @return
     */
    int modifyEntranceBaseStatus(@Param("id") long id, @Param("status") int status);
}
