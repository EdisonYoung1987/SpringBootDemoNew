package com.sjht.cloud.entrance.service.impl;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.sjht.cloud.entrance.api.dto.CreateAuditLogDto;
import com.sjht.cloud.entrance.dao.EntranceAuditLogMapper;
import com.sjht.cloud.entrance.entity.EntranceAuditLogEntity;
import com.sjht.cloud.entrance.service.EntranceAuditLogService;
import com.sjht.cloud.framework.common.entity.response.ResponseDataResult;
import com.sjht.cloud.framework.common.entity.response.ResponseResult;
import com.sjht.cloud.framework.common.entity.response.ResponseUtil;
import com.sjht.cloud.framework.common.enums.CommonCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * ***************************************************
 * @ClassName EntranceAuditLogServiceImpl
 * @Description 描述
 * @Author maojianyun
 * @Date 2020/3/9 13:27
 * @Version V1.0
 * ****************************************************
 **/
@Service
public class EntranceAuditLogServiceImpl implements EntranceAuditLogService {

    @Autowired
    private EntranceAuditLogMapper auditLogMapper;

    @Override
    public ResponseResult createAuditLog(CreateAuditLogDto auditLogDto) {
        EntranceAuditLogEntity entity = new EntranceAuditLogEntity();
        entity.setId(IdWorker.getId());
        entity.setContent(auditLogDto.getContent());
        entity.setStatus(auditLogDto.getStatus());
        int n = auditLogMapper.insert(entity);
        if (n > 0) {
            return ResponseUtil.SUCCESS();
        }
        return ResponseUtil.FAIL();
    }

    @Override
    public ResponseResult updateAuditLogStatus(String id, int status) {
        int n = auditLogMapper.updateAuditLogStatus(Long.valueOf(id), status);
        if (n > 0) {
            return ResponseUtil.SUCCESS();
        }
        return ResponseUtil.FAIL();
    }

    @Override
    public ResponseDataResult getAuditLogContent(String appliId, int status) {
        String countent = auditLogMapper.getAuditLogContent(Long.valueOf(appliId), status);
        if (countent != null) {
            return ResponseUtil.SUCCESS(countent);
        }
        return ResponseUtil.SUCCESS(CommonCode.NULL, null);
    }

    @Override
    public ResponseDataResult getAuditStatus(String id) {
        Map<String, String> data = new HashMap<>();
        String status = auditLogMapper.getAuditStatus(id);
        data.put("status", status);
        return ResponseUtil.SUCCESS(data);
    }
}
