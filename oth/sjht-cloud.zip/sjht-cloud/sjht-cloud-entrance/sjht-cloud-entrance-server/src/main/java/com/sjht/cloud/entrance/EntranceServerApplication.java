package com.sjht.cloud.entrance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.origin.SystemEnvironmentOrigin;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * ***************************************************
 * @ClassName EntranceServerApplication
 * @Description 入学服务启动入口
 * @Author maojianyun
 * @Date 2019/12/25 10:02
 * @Version V1.0
 * ****************************************************
 **/
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
@RefreshScope
public class EntranceServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(EntranceServerApplication.class, args);
        System.out.println("————————————————————————入学服务启动成功————————————————————————");
    }
}
