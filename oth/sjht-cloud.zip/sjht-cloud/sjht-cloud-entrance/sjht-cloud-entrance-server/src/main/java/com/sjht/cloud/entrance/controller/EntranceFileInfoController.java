package com.sjht.cloud.entrance.controller;

import com.sjht.cloud.entrance.service.EntranceFileInfoService;
import com.sjht.cloud.framework.common.entity.response.ResponseDataResult;
import com.sjht.cloud.framework.common.entity.response.ResponseResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * ***************************************************
 * @ClassName EntranceFileInfoController
 * @Description 文件api
 * @Author maojianyun
 * @Date 2020/3/5 10:42
 * @Version V1.0
 * ****************************************************
 **/
@RestController
@RequestMapping("file")
@Api(value = "入学申请管理-文件接口", tags = {"入学申请管理-文件接口"})
public class EntranceFileInfoController {

    @Autowired
    private EntranceFileInfoService fileInfoService;

    /**
     * 文件上传
     * @param multipartFile
     * @return
     */
    @PostMapping("fileUpload")
    @ApiOperation(value = "入学申请-删除已有的文件")
    public ResponseDataResult fileUpload(@RequestParam MultipartFile multipartFile){
        return fileInfoService.fileUpload(multipartFile);
    }

    @PostMapping("upload")
    @ApiOperation(value = "入学申请-上传接口")
    public ResponseDataResult upload(HttpServletRequest request, @RequestParam(value = "file", required = false) MultipartFile file) throws IOException {
        return fileInfoService.fileUpload(file);
    }

    /**
     * 删除文件
     * @param fileId
     * @return
     */
    @PostMapping("deleFile")
    @ApiOperation(value = "入学申请-新文件上传")
    public ResponseResult deleFile(@RequestParam String fileId){
        return fileInfoService.deleFile(fileId);
    }



}
