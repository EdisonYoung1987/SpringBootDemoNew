package com.sjht.cloud.gateway.service;

import org.springframework.http.HttpHeaders;

/**
 * ***************************************************
 * @ClassName GateWayAuthService
 * @Description auth接口
 * @Author maojianyun
 * @Date 2019/12/10 16:28
 * @Version V1.0
 * ****************************************************
 **/
public interface GateWayAuthService {

    /**
     * 从头部取出jwt令牌
     * @param headers
     * @return
     */
    String getJwtFromHeader(HttpHeaders headers);

    /**
     * 从头部取出token
     * @param headers
     * @return
     */
    String getTokenFromHead(HttpHeaders headers);

    /**
     * 有效期查询
     * @param access_token
     * @return
     */
    long getExpire(String access_token);
}
