package com.sjht.cloud.ucenter.api.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * ***************************************************
 *
 * @ClassName ChangePasswordDto
 * @Description
 * @Author 张弛
 * @Date 2020/4/3 16:02
 * @Version V1.0
 * ****************************************************
 **/
@Data
@ToString
@ApiModel(value = "ChangePasswordDto", description = "改密Dto")
public class ChangePasswordDto implements Serializable {
    private String id;
    private String oldpw;
    private String newpw;
}
