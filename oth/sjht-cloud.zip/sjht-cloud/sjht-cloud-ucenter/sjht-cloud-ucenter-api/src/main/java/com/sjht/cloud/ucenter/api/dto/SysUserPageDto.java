package com.sjht.cloud.ucenter.api.dto;

import com.sjht.cloud.framework.common.entity.request.PageDto;
import io.swagger.annotations.ApiModel;

@ApiModel(value="SysUserPageDto", description="系统用户分页DTO")
public class SysUserPageDto extends PageDto{

	private static final long serialVersionUID = -4631059083432915372L;

	
}
