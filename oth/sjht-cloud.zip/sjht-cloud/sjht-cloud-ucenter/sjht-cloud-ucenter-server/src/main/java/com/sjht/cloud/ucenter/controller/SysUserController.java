package com.sjht.cloud.ucenter.controller;

import com.sjht.cloud.framework.common.entity.response.ResponseDataResult;
import com.sjht.cloud.framework.common.entity.response.ResponseResult;
import com.sjht.cloud.ucenter.api.dto.ChangePasswordDto;
import com.sjht.cloud.ucenter.api.dto.PageUserListDto;
import com.sjht.cloud.ucenter.api.dto.RegisteredDto;
import com.sjht.cloud.ucenter.api.dto.UserDto;
import com.sjht.cloud.ucenter.service.SysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@Api(value = "用户管理-用户接口", tags = {"用户管理-用户接口"})
public class SysUserController {

	@Autowired
	private SysUserService sysUserService;

	@GetMapping("getUserInfoByUserNmae")
	@ApiOperation(value = "用户管理-根据用户名得到用户信息")
	public ResponseDataResult getUserInfoByUserNmae(@RequestParam("userName") String userName) {
		return sysUserService.getUserInfoByUserNmae(userName);
	}

	@PostMapping("pageUserList")
	@ApiOperation(value = "用户管理-分页获取用户列表")
	public ResponseDataResult pageUserList(@RequestBody PageUserListDto listDto) {
		return sysUserService.pageUserList(listDto);
	}

	@PostMapping("createUser")
	@ApiOperation(value = "用户管理-创建用户")
	public ResponseResult createUser(@RequestBody UserDto userDto){
		return sysUserService.createUser(userDto);
	}

	@PostMapping("userEditeSubmit")
	@ApiOperation(value = "用户管理-用户编辑提交")
	public ResponseResult userEditeSubmit(@RequestBody UserDto userDto){
		return sysUserService.userEditeSubmit(userDto);
	}

	@GetMapping("deleteUser/{id}")
	@ApiOperation(value = "用户管理-用户编辑提交")
	public ResponseResult deleteUser(@PathVariable("id") long id){
		return sysUserService.deleteUser(id);
	}

	@PostMapping("registered")
	@ApiOperation(value = "用户管理-手机端用户注册")
	public ResponseResult registered(@RequestBody RegisteredDto registeredDto){
		return sysUserService.registered(registeredDto);
	}

	@PostMapping("changePassword")
	@ApiOperation(value = "用户管理-改密")
	public ResponseResult registered(@RequestBody ChangePasswordDto changePasswordDto){
		return sysUserService.changePassword(changePasswordDto);
	}
}
