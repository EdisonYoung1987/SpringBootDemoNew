package com.sjht.cloud.ucenter.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sjht.cloud.ucenter.api.dto.PageUserListDto;
import com.sjht.cloud.ucenter.api.vo.AuthUserVo;
import com.sjht.cloud.ucenter.api.vo.UserVo;
import com.sjht.cloud.ucenter.entity.SysUserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 ************************************************
 *@ClassName SysUserMapper
 *@Description 系统用户数据层
 *@Author maojianyun
 *@Date 2019/9/5 9:43
 *@Version V1.0
 *************************************************
 **/
@Component
@Mapper
public interface SysUserMapper extends BaseMapper<SysUserEntity>{

    /**
     * 根据用户名得到用户信息
     * @param userName
     * @return
     */
    AuthUserVo getUserInfoByUserNmae(@Param("userName") String userName);


    /**
     * 根据用户id查询用户权限
    * @param userId
     * @return
     */
    List<String> getPermsByUserId(@Param("userId") String userId);

    /**
     * 分页得到用户列表
     * @param page
     * @param listDto
     * @return
     */
    List<UserVo> pageUserList(Page<UserVo> page, @Param("params")PageUserListDto listDto);
}
